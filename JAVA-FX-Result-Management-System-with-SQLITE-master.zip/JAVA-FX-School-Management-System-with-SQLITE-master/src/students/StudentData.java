package students;



import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;


public class StudentData
{
  private final StringProperty ID;
  private final StringProperty firstName;
  private final StringProperty lastName;
  private final StringProperty English;
  private final StringProperty Maths;
  private final StringProperty Science;
  private final StringProperty TotalGrade;
  public StudentData(String id, String firstname, String lastname,String english,String maths,String science,String totalgrade)
  {
    this.ID = new SimpleStringProperty(id);
    this.firstName = new SimpleStringProperty(firstname);
    this.lastName = new SimpleStringProperty(lastname);
 
     this.English = new SimpleStringProperty(english);
      this.Maths = new SimpleStringProperty(maths);
       this.Science = new SimpleStringProperty(science);
        this.TotalGrade = new SimpleStringProperty(totalgrade);
  }

    
  
  public String getID()
  {
    return (String)this.ID.get();
  }
  
  public String getFirstName()
  {
    return (String)this.firstName.get();
  }
  
  public String getLastName()
  {
    return (String)this.lastName.get();
  }
  

  
    public String getenglish()
  {
    return (String)this.English.get();
  }
  
    public String getmaths()
  {
    return (String)this.Maths.get();
  }
    public String getscience()
  {
    return (String)this.Science.get();
  }
    public String getTotalGrade()
  {
    return (String)this.TotalGrade.get();
  }
  
    
    
    
  public void setID(String value)
  {
    this.ID.set(value);
  }
  
  public void setFirstName(String value)
  {
    this.firstName.set(value);
  }
  
  public void setLastName(String value)
  {
    this.lastName.set(value);
  }
  

   public void setEnglish(String value)
  {
    this.English.set(value);
  }
    public void setMaths(String value)
  {
    this.Maths.set(value);
  }
     public void setScience(String value)
  {
    this.Science.set(value);
  }
      public void setTotalGrade(String value)
  {
    this.TotalGrade.set(value);
  }
      
      
  public StringProperty idProperty()
  {
    return this.ID;
  }
  
  public StringProperty firstNameProperty()
  {
    return this.firstName;
  }
  
  public StringProperty lastNameProperty()
  {
    return this.lastName;
  }
  

   public StringProperty englishProperty()
  {
    return this.English;
  }
    public StringProperty mathsProperty()
  {
    return this.Maths;
  }
     public StringProperty scienceProperty()
  {
    return this.Science;
  }
      public StringProperty TotalGradeProperty()
  {
    return this.TotalGrade;
  }
      
}
