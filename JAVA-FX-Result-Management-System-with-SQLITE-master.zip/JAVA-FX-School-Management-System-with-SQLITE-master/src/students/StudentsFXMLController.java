package students;


import dbUtil.dbConnection;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;

import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import loginapp.LoginApp;
import loginapp.LoginMainController;

public class StudentsFXMLController
  implements Initializable
{
  private TextField id;
  private TextField firstname;
  private TextField lastname;

    private TextField english;

    private TextField maths;

    private TextField science;

    private TextField totalgrade;
   
  @FXML
  private TableView<StudentData> studenttable;
    @FXML
  private TableView<StudentData> studenttable1;
     @FXML
  private TableView<StudentData> studenttable2;
  @FXML
  private TableColumn<StudentData, String> idcolumn;
  @FXML
  private TableColumn<StudentData, String> firstnamecolumn;
  @FXML
  private TableColumn<StudentData, String> lastnamecolumn;

      @FXML
    private TableColumn<StudentData, String> engcolumn;

    @FXML
    private TableColumn<StudentData, String> mathcolumn;

    @FXML
    private TableColumn<StudentData, String> scicolumn;

    @FXML
    private TableColumn<StudentData, String> totalgradecolumn;
  private ObservableList<StudentData> data;
  private dbConnection dc;
   
    @FXML
    private Button clearFields;
    @FXML
    private TextField stuid;
    @FXML
    private Button logoutbutton;
  
  public void initialize(URL url, ResourceBundle rb)
          
          
  {  
    this.dc = new dbConnection();
  }
  
  @FXML
  private void loadStudentData(ActionEvent event)
  {
    try
    {
      Connection conn = dbConnection.getConnection();
      this.data = FXCollections.observableArrayList();
      
      ResultSet rs = conn.createStatement().executeQuery("SELECT id,fname,lname,English,Maths,Science,TotalGrade FROM students Where id="+this.stuid.getText());
      
      while (rs.next()) {
        this.data.add(new StudentData(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7)));
      }
    }
    catch (SQLException e)
    {
      System.err.println("Error " + e);
    }
    this.idcolumn.setCellValueFactory(new PropertyValueFactory("ID"));
    this.firstnamecolumn.setCellValueFactory(new PropertyValueFactory("firstName"));
    this.lastnamecolumn.setCellValueFactory(new PropertyValueFactory("lastName"));
      this.engcolumn.setCellValueFactory(new PropertyValueFactory("english"));
        this.mathcolumn.setCellValueFactory(new PropertyValueFactory("maths"));
          this.scicolumn.setCellValueFactory(new PropertyValueFactory("science"));
            this.totalgradecolumn.setCellValueFactory(new PropertyValueFactory("TotalGrade"));
    
    this.studenttable.setItems(null);
    this.studenttable.setItems(this.data);
       this.studenttable1.setItems(null);
    this.studenttable1.setItems(this.data);
     this.studenttable2.setItems(null);
    this.studenttable2.setItems(this.data);
  }
  

  
  @FXML
  private void clearFields(ActionEvent event)
  {
    this.stuid.setText("");
    
  }

    @FXML
    private void logout(ActionEvent event) {
        
   
          try
    {
     
      
        Stage stage = (Stage)this.logoutbutton.getScene().getWindow();
        Login();
        stage.close();
     
     
    }
    catch (Exception localException) {}
    }
    
   public void Login()
  {
    try
    {
      Stage userStage = new Stage();
      FXMLLoader loader = new FXMLLoader();
      Pane root = (Pane)loader.load(getClass().getResource("/loginapp/LoginMain.fxml").openStream());
      LoginMainController studentController = (LoginMainController)loader.getController();
      
      Scene scene = new Scene(root);
      userStage.setScene(scene);
      userStage.show();
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }
  }
    }

 
 
    


