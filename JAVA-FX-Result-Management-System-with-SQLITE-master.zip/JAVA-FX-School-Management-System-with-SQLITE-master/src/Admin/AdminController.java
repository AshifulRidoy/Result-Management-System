package Admin;

import dbUtil.dbConnection;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import loginapp.LoginMainController;

public class AdminController
  implements Initializable
{
  @FXML
  private TextField id;
  @FXML
  private TextField firstname;
  @FXML
  private TextField lastname;
  @FXML
  private TextField email;
  @FXML
  private DatePicker dob;
      @FXML
    private TextField english;

    @FXML
    private TextField maths;

    @FXML
    private TextField science;

    @FXML
    private TextField totalgrade;
  @FXML
  private TableView<StudentData> studenttable;
  @FXML
  private TableColumn<StudentData, String> idcolumn;
  @FXML
  private TableColumn<StudentData, String> firstnamecolumn;
  @FXML
  private TableColumn<StudentData, String> lastnamecolumn;
  @FXML
  private TableColumn<StudentData, String> emailcolumn;
  @FXML
  private TableColumn<StudentData, String> dobcolumn;
      @FXML
    private TableColumn<StudentData, String> engcolumn;

    @FXML
    private TableColumn<StudentData, String> mathcolumn;

    @FXML
    private TableColumn<StudentData, String> scicolumn;

    @FXML
    private TableColumn<StudentData, String> totalgradecolumn;
  private ObservableList<StudentData> data;
  private dbConnection dc;
    @FXML
    private Button clearFields;
    @FXML
    private Button logoutbutton;
  
  public void initialize(URL url, ResourceBundle rb)
  {
    this.dc = new dbConnection();
  }
  
  @FXML
  private void loadStudentData(ActionEvent event)
  {
    try
    {
      Connection conn = dbConnection.getConnection();
      this.data = FXCollections.observableArrayList();
      
      ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM students");
      while (rs.next()) {
        this.data.add(new StudentData(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9)));
      }
    }
    catch (SQLException e)
    {
      System.err.println("Error " + e);
    }
    this.idcolumn.setCellValueFactory(new PropertyValueFactory("ID"));
    this.firstnamecolumn.setCellValueFactory(new PropertyValueFactory("firstName"));
    this.lastnamecolumn.setCellValueFactory(new PropertyValueFactory("lastName"));
    this.emailcolumn.setCellValueFactory(new PropertyValueFactory("email"));
    this.dobcolumn.setCellValueFactory(new PropertyValueFactory("DOB"));
      this.engcolumn.setCellValueFactory(new PropertyValueFactory("english"));
        this.mathcolumn.setCellValueFactory(new PropertyValueFactory("maths"));
          this.scicolumn.setCellValueFactory(new PropertyValueFactory("science"));
            this.totalgradecolumn.setCellValueFactory(new PropertyValueFactory("TotalGrade"));
    
    this.studenttable.setItems(null);
    this.studenttable.setItems(this.data);
  }
  
  @FXML
  private void addStudent(ActionEvent event)
  {
    String sql = "INSERT INTO `students`(`id`, `fname`, `lname`, `email`, `DOB`,`English`,`Maths`,`Science`,`TotalGrade`) VALUES (? , ?, ?, ?, ?, ?, ?, ?, ?)";
    try
    {
      Connection conn = dbConnection.getConnection();
      PreparedStatement stmt = conn.prepareStatement(sql);
      stmt.setString(1, this.id.getText());
      stmt.setString(2, this.firstname.getText());
      stmt.setString(3, this.lastname.getText());
      stmt.setString(4, this.email.getText());
      stmt.setString(5, this.dob.getEditor().getText());
       stmt.setString(6, this.english.getText());
        stmt.setString(7, this.maths.getText());
         stmt.setString(8, this.science.getText());
          stmt.setString(9, this.totalgrade.getText());
      stmt.execute();
      conn.close();
    }
    catch (SQLException e)
    {
      System.err.println("Got an exception!");
      System.err.println(e.getMessage());
    }
  }
  
  @FXML
  private void clearFields(ActionEvent event)
  {
    this.id.setText("");
    this.firstname.setText("");
    this.lastname.setText("");
    this.email.setText("");
    this.dob.setValue(null);
     this.english.setText("");
      this.maths.setText("");
       this.science.setText("");
        this.totalgrade.setText("");
  }

    @FXML
    private void logout(ActionEvent event) {
               try
    {
     
      
        Stage stage = (Stage)this.logoutbutton.getScene().getWindow();
        Login();
        stage.close();
     
     
    }
    catch (Exception localException) {}
    }
    
       public void Login()
  {
    try
    {
      Stage userStage = new Stage();
      FXMLLoader loader = new FXMLLoader();
      Pane root = (Pane)loader.load(getClass().getResource("/loginapp/LoginMain.fxml").openStream());
      LoginMainController studentController = (LoginMainController)loader.getController();
      
      Scene scene = new Scene(root);
      userStage.setScene(scene);
      userStage.show();
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }
  }
}
